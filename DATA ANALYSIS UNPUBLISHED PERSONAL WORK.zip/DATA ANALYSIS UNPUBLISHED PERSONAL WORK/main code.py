#!/usr/bin/env python
# coding: utf-8

# # IMPORT MODULES

# In[7]:


import pandas as pd
from sklearn.metrics import r2_score
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# # DATASET LOADING & VISUALIZATION

# In[190]:


dfn = pd.read_csv('Dataset.csv')
dfn.head(61)




# In[182]:


dfn = pd.read_csv('Dataset.csv')

dfn=dfn.dropna()

df = dfn.drop(['S.N'], axis=1)

df.info()

plt.figure(figsize=(12,10))
sns.heatmap(df.corr(),annot=True)
plt.savefig('heatmap.png', dpi=300)


# In[9]:


y=df['BTM(F)']


# In[10]:


X = df.drop('BTM(F)',axis=1)


# # DATASET SPLITTING TO TRAIN & TEST SET

# In[11]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,random_state=101)


# In[12]:


X_train .shape


# In[13]:


X_test.shape


# In[14]:


# reduce the number of the input data by using filtter by correlation method
def correlation(dataset,threshold):
    col_corr = set()
    corr_matrix = dataset.corr()
    for i in range(len(corr_matrix.columns)):
        for j in range(i):
            if abs(corr_matrix.iloc[i,j]) > threshold:
                colname= corr_matrix.columns[i]
                col_corr.add(colname)
                return col_corr


# In[15]:


corr_features = correlation(X_train,0.80)
len(set(corr_features))


# In[16]:


corr_features


# In[17]:


#drop the corr features from the X_test and X-train
X_train.drop(labels=corr_features,axis=1,inplace=True)
X_test.drop(labels=corr_features,axis=1,inplace=True)
X_train.shape,X_test.shape


# In[18]:


df_train=pd.DataFrame(X_train)


# In[19]:


df_test=pd.DataFrame(X_test)


# In[20]:


X_test.skew()


# In[21]:


# Plot the histogram of train daat
plt.close()
fig=plt.figure()
for i in range (len(df_train.columns)):
    plt.subplot(8,1,i+1)
    plt.figure(figsize = (5, 5))
    plt.hist(df_train[df_train.columns[i]],bins = 50)
    plt.xlabel(df_train.columns[i])
    plt.ylabel("Frequency")
    plt.grid()
#plt.savefig("train dis_%.png" %i)
fig.savefig('train dis'+str(i)+'.png')
plt.show();


# In[22]:


# Plot the histogram of test daat
for i in range (len(df_test.columns)):
    plt.subplot(8,1,i+1)
    plt.figure(figsize = (5, 5))
    plt.hist(df_test[df_test.columns[i]],bins = 50)
    plt.xlabel(df_test.columns[i])
    plt.ylabel("Frequency")
    plt.grid()
    plt.show();


# # DATASET PREPROCESSING & SCALING

# In[23]:


from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()


# In[24]:


#To prevent data leakage fit only to the train
scaler.fit(X_train)


# In[25]:


X_test = scaler.transform(X_test)
X_train = scaler.transform(X_train)


# In[26]:


X_train.max()


# # MACHINE LEARNING MODELS

# # Linear Regression Model

# In[27]:


#Linear Regression Model

from sklearn.linear_model import LinearRegression
from sklearn import metrics
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
get_ipython().run_line_magic('matplotlib', 'inline')

lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train)
y_pred_LR = lin_reg.predict(X_test) # then predict on the test set
y_pred_LR_t = lin_reg.predict(X_train)

MAE = metrics.mean_absolute_error(y_train, y_pred_LR_t)
MSE = metrics.mean_squared_error(y_train, y_pred_LR_t)
R = r2_score(y_train, y_pred_LR_t)
RMSE = np.sqrt(metrics.mean_squared_error(y_train, y_pred_LR_t))
MAPE = np.mean(np.abs((y_train - y_pred_LR_t)/y_train )) * 100

print(f"The MAE of model {type(lin_reg).__name__} is {MAE:.2f}")
print(f"The MSE of model {type(lin_reg).__name__} is {MSE:.2f}")
print(f"The RMSE of model {type(lin_reg).__name__} is {RMSE:.2f}")
print(f"The MAPE of model {type(lin_reg).__name__} is {MAPE:.2f}")
print(f"The R of model {type(lin_reg).__name__} is {R:.2f}")
print("\n")

LR_Train = plt.scatter(y_train,y_pred_LR_t,color ='red',marker='*',label="Lin_Reg_Train")
plt.xlabel(('Actual BTM(F) '))
plt.ylabel(('Predicted BTM(F) '))
R = r2_score(y_train, y_pred_LR_t)
plt.title('Training cross-Plot of Linear Regression Model ')
plt.grid()
m_train, b_train = np.polyfit(y_train, y_pred_LR_t, 1)
plt.plot(y_train, m_train*y_train+b_train,linestyle='--',c='blue',label= "R_Lin_train = 0.86")
plt.legend()


# In[28]:


MAE = metrics.mean_absolute_error(y_test, y_pred_LR)
MSE = metrics.mean_squared_error(y_test, y_pred_LR)
MAPE = np.mean(np.abs((y_test - y_pred_LR)/y_test)) * 100
R = r2_score(y_test, y_pred_LR)
RMSE = np.sqrt(metrics.mean_squared_error(y_test, y_pred_LR))

print(f"The MAE of model {type(lin_reg).__name__} is {MAE:.2f}")
print(f"The MSE of model {type(lin_reg).__name__} is {MSE:.2f}")
print(f"The RMSE of model {type(lin_reg).__name__} is {RMSE:.2f}")
print(f"The MAPE of model {type(lin_reg).__name__} is {MAPE:.2f}")
print(f"The R of model {type(lin_reg).__name__} is {R:.2f}")
print("\n")

LR_Test = plt.scatter(y_test,y_pred_LR, color ='red',marker='*',label="Lin_Reg_Test")
plt.xlabel(('Actual BTM(F) '))
plt.ylabel(('Predicted BTM(F) '))
R = r2_score(y_test, y_pred_LR)
plt.title('Testing cross-plot of Linear Regression model ')
m_test, b_test = np.polyfit(y_test, y_pred_LR, 1)
plt.grid()
print(R)
plt.plot(y_test, m_test*y_test+b_test,linestyle='--',c='blue',label="R_Lin_Test = 0.80")
plt.legend()


# # Polynomial Regression Model

# In[29]:


X_train.shape


# In[30]:


y_train.shape


# In[32]:


#Polynomial Regression Model

from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge

poly_reg = PolynomialFeatures(degree = 4)
X_poly_train = poly_reg.fit_transform(X_train)
lin_reg = LinearRegression()
lin_reg.fit(X_poly_train, y_train)
y_Pred_pol_t = lin_reg.predict(X_poly_train)

Poly_Reg_Train = plt.scatter(y_train,y_Pred_pol_t, color='red',marker='+',label='Poly_Reg_Train')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
R = r2_score(y_train, y_Pred_pol_t)
plt.title('Training Cross-Plot of Polynomial Regression model ')
plt.grid()
print(R)
m_poly, b_poly = np.polyfit(y_train, y_Pred_pol_t, 1)
plt.plot(y_train, m_poly*y_train+b_poly,linestyle='--',c='blue',label='R_Poly_train = 1.0')
plt.legend()


# In[35]:


lin_reg = LinearRegression()
X_poly_test = poly_reg.fit_transform(X_test)
lin_reg.fit(X_poly_test, y_test)
y_pred_pol = lin_reg.predict(X_poly_test)

Poly_Reg_Test = plt.scatter(y_test,y_pred_pol, color='red',marker='+',label='Poly_Reg_Test')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
R = r2_score(y_test, y_pred_pol)
plt.title('Training Cross-Plot of Polynomial Regression model ')
plt.grid()
print(R)
m_poly_test, b_poly_test = np.polyfit(y_test, y_pred_pol, 1)
plt.plot(y_test, m_poly_test*y_test+b_poly_test,linestyle='--',c='blue',label='R_Poly_test = 1.0')
plt.legend()


# # Decision Tree Model

# In[36]:


#Decision Tree Model

from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
from sklearn import metrics
from sklearn.metrics import accuracy_score
from sklearn.metrics import r2_score


# In[37]:


k_range = list(range(1,40))
weight_options = ["uniform", "distance"]
param_grid = dict(n_neighbors = k_range, weights = weight_options)

knn = KNeighborsRegressor()
grid = GridSearchCV(knn, param_grid, cv = 10)
grid.fit(X,y)

print (grid.best_params_)


# In[39]:


#first, initialize the classificators
tree = DecisionTreeRegressor( splitter = 'random', max_leaf_nodes = 10, min_samples_leaf = 5, max_depth= 5)
tree = DecisionTreeRegressor(random_state=24) # using the random state for reproducibility


# In[43]:


# fit the model
tree.fit(X_train, y_train) 

# then predict on the train set
y_pred_tree_t = tree.predict(X_train)

    
MAE=metrics.mean_absolute_error(y_train, y_pred_tree_t)
MAE=metrics.mean_absolute_error(y_train, y_pred_tree_t)
MSE= metrics.mean_squared_error(y_train, y_pred_tree_t)
MAPE=np.mean(np.abs((y_train - y_pred_tree_t) /y_train )) * 100
R = r2_score(y_train, y_pred_tree_t)
RMSE= np.sqrt(metrics.mean_squared_error(y_train, y_pred_tree_t))

print(f"The MAE of model {type(tree).__name__} is {MAE:.2f}")
print(f"The MSE of model {type(tree).__name__} is {MSE:.2f}")
print(f"The RMSE of model {type(tree).__name__} is {RMSE:.2f}")
print(f"The MAPE of model {type(tree).__name__} is {MAPE:.2f}")
print(f"The R of model {type(tree).__name__} is {R:.2f}")
print("\n")

Dec_tree_Train = plt.scatter(y_train,y_pred_tree_t, color='red',marker='+',label='Dec_Tree_Train')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
R = r2_score(y_train, y_pred_tree_t)
plt.title('Training Cross-Plot of Decision Tree Model')
plt.grid()
print(R)

m_tree_train, b_tree_train = np.polyfit(y_train, y_pred_tree_t, 1)
plt.plot(y_train, m_tree_train*y_train+b_tree_train,linestyle='--',c='blue',label='R_Tree_Train = 1.0')
plt.legend()


# In[44]:


# fit the model
tree.fit(X_test, y_test) 

# then predict on the test set
y_pred_tree = tree.predict(X_test)
    
MAE=metrics.mean_absolute_error(y_test, y_pred_tree)
MAE=metrics.mean_absolute_error(y_test, y_pred_tree)
MSE= metrics.mean_squared_error(y_test, y_pred_tree)
MAPE=np.mean(np.abs((y_test - y_pred_tree) /y_test )) * 100
R = r2_score(y_test, y_pred_tree)
RMSE= np.sqrt(metrics.mean_squared_error(y_test, y_pred_tree))

print(f"The MAE of model {type(tree).__name__} is {MAE:.2f}")
print(f"The MSE of model {type(tree).__name__} is {MSE:.2f}")
print(f"The RMSE of model {type(tree).__name__} is {RMSE:.2f}")
print(f"The MAPE of model {type(tree).__name__} is {MAPE:.2f}")
print(f"The R of model {type(tree).__name__} is {R:.2f}")
print("\n")

Dec_tree_Test = plt.scatter(y_test,y_pred_tree, color='red',marker='+',label='Dec_Tree_Train')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
R = r2_score(y_test, y_pred_tree)
plt.title('Testing Cross-Plot of Decision Tree Model')
plt.grid()
print(R)
m_tree_test, b_tree_test = np.polyfit(y_test, y_pred_tree, 1)
plt.plot(y_test, m_tree_test*y_test+ b_tree_test,linestyle='--',c='blue',label='R_Tree_Test = 1.0')
plt.legend()


# # Random Forest Model

# In[46]:


forest = RandomForestRegressor(random_state=48)


forest.fit(X_train, y_train) # fit the model
y_pred_forest = forest.predict(X_test)# then predict on the test set
y_pred_forest_t = forest.predict(X_train)
    
    
MAE=metrics.mean_absolute_error(y_train, y_pred_forest_t)
MSE= metrics.mean_squared_error(y_train, y_pred_forest_t)
MAPE=np.mean(np.abs((y_train - y_pred_forest_t) /y_train )) * 100
#R = r2_score(y_test, y_forest_test)
R = r2_score(y_train, y_pred_forest_t)
#RMSE= np.sqrt(metrics.mean_squared_error(y_test, y_forest_test))
RMSE= np.sqrt(metrics.mean_squared_error(y_train, y_pred_forest_t))

print(f"The MAE of model {type(forest).__name__} is {MAE:.2f}")
print(f"The MSE of model {type(forest).__name__} is {MSE:.2f}")
print(f"The RMSE of model {type(forest).__name__} is {RMSE:.2f}")
print(f"The MAPE of model {type(forest).__name__} is {MAPE:.2f}")
print(f"The R of model {type(forest).__name__} is {R:.2f}")
print("\n")

Ran_forest_Train = plt.scatter(y_train,y_pred_forest_t, color='red',marker='+',label='Ran_Forest_Train')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
R = r2_score(y_train, y_pred_forest_t)
plt.title('Training Cross-Plot of Random Forest Model')
plt.grid()
print(R)
m_forest_train, b_forest_train = np.polyfit(y_train, y_pred_forest_t, 1)
plt.plot(y_train, m_forest_train*y_train+b_forest_train,linestyle='--',c='blue',label='R_Forest_Train = 0.99')
plt.legend()


# In[51]:



MAE=metrics.mean_absolute_error(y_test, y_pred_forest)
MSE= metrics.mean_squared_error(y_test, y_pred_forest)
MAPE=np.mean(np.abs((y_test - y_pred_forest) /y_test)) * 100
#R = r2_score(y_test, y_forest_test)
R = r2_score(y_test, y_pred_forest)
#RMSE= np.sqrt(metrics.mean_squared_error(y_test, y_forest_test))
RMSE= np.sqrt(metrics.mean_squared_error(y_test, y_pred_forest))

print(f"The MAE of model {type(forest).__name__} is {MAE:.2f}")
print(f"The MSE of model {type(forest).__name__} is {MSE:.2f}")
print(f"The RMSE of model {type(forest).__name__} is {RMSE:.2f}")
print(f"The MAPE of model {type(forest).__name__} is {MAPE:.2f}")
print(f"The R of model {type(forest).__name__} is {R:.2f}")
print("\n")

Ran_forest_Test = plt.scatter(y_test,y_pred_forest, color='red',marker='+',label='Random Forest_Test')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
plt.title('Training Cross-Plot of Random Forest Model')
plt.grid()
print(R)
             
m_forest_test, b_forest_test = np.polyfit(y_test, y_pred_forest, 1)
plt.plot(y_test, m_forest_test*y_test+b_forest_test,linestyle='--',c='blue',label='R_forest_test = 0.91')
plt.legend()


# In[53]:


tree = DecisionTreeRegressor( splitter = 'random', max_leaf_nodes = 10, min_samples_leaf = 5, max_depth= 5)
tree = DecisionTreeRegressor(random_state=24) # using the random state for reproducibility
forest = RandomForestRegressor(random_state=48)
knn = KNeighborsRegressor(8,weights = "distance")
svm = SVC(random_state = 24)

models = [tree, forest, knn]
from sklearn import metrics
from sklearn.metrics import accuracy_score
from sklearn.metrics import r2_score
for model in models:
    model.fit(X_train, y_train) # fit the model
    y_pred= model.predict(X_test)# then predict on the test set
    y_pred_t=model.predict(X_train)
    
    
MAE=metrics.mean_absolute_error(y_test, y_pred)
MAE=metrics.mean_absolute_error(y_test, y_pred)
MSE= metrics.mean_squared_error(y_test, y_pred)
MAPE=np.mean(np.abs((y_train - y_pred_t) /y_train )) * 100
MAPE=np.mean(np.abs((y_test - y_pred) /y_test )) * 100
R = r2_score(y_test, y_pred)
RMSE= np.sqrt(metrics.mean_squared_error(y_test, y_pred))

print(f"The MAE of model {type(models).__name__} is {MAE:.2f}")
print(f"The MSE of model {type(models).__name__} is {MSE:.2f}")
print(f"The RMSE of model {type(models).__name__} is {RMSE:.2f}")
print(f"The MAPE of model {type(models).__name__} is {MAPE:.2f}")
print(f"The R of model {type(models).__name__} is {R:.2f}")
print("\n")
    


# # K-Nearest Neighbour Model

# In[62]:


knn = KNeighborsRegressor(8,weights = "distance")
svm = SVC(random_state = 24)


knn.fit(X_train, y_train) # fit the model
y_pred_knn = knn.predict(X_test)# then predict on the test set
y_pred_knn_t = knn.predict(X_train)
    
    
MAE=metrics.mean_absolute_error(y_train, y_pred_knn_t)
MAE=metrics.mean_absolute_error(y_train, y_pred_knn_t)
MSE= metrics.mean_squared_error(y_train, y_pred_knn_t)
MAPE=np.mean(np.abs((y_train - y_pred_knn_t) /y_train )) * 100
R = r2_score(y_train, y_pred_knn_t)
RMSE= np.sqrt(metrics.mean_squared_error(y_train, y_pred_knn_t))

print(f"The MAE of model {type(knn).__name__} is {MAE:.2f}")
print(f"The MSE of model {type(knn).__name__} is {MSE:.2f}")
print(f"The RMSE of model {type(knn).__name__} is {RMSE:.2f}")
print(f"The MAPE of model {type(knn).__name__} is {MAPE:.2f}")
print(f"The R of model {type(knn).__name__} is {R:.2f}")
print("\n")

knn_Train = plt.scatter(y_train, y_pred_knn_t, color='red',marker='+',label='K-Nearest Neighbour_Train')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
plt.title('Training Cross-Plot of K-Nearest Neighbour Model')
plt.grid()
print(R)
             
m_knn_train, b_knn_train = np.polyfit(y_train, y_pred_knn_t, 1)
plt.plot(y_train, m_knn_train*y_train+b_knn_train,linestyle='--',c='blue',label='R_knn = 1.0')
plt.legend()


# In[60]:


R = r2_score(y_test, y_pred_knn)

knn_Test = plt.scatter(y_test, y_pred_knn, color='red',marker='+',label='K-Nearest Neighbour_Test')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
plt.title('Testing Cross-Plot of K-Nearest Neighbour Model')
plt.grid()
print(R)
             
m_knn_test, b_knn_test = np.polyfit(y_test, y_pred_knn, 1)
plt.plot(y_test, m_knn_test*y_test+b_knn_test,linestyle='--',c='blue',label='R_knn = 0.82')
plt.legend()


# # Artificial Neural Network (ANN) Model

# In[63]:


#Artificial Neural Network (ANN)

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation


# In[64]:


# Improving the ANN
# Dropout Regularization to reduce overfitting if needed
# Tuning the ANN

from tensorflow.keras.wrappers.scikit_learn import KerasRegressor
from sklearn.model_selection import GridSearchCV
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

def build_regressor(optimizer):
    regressor = Sequential()
    regressor.add(Dense(units = 8, kernel_initializer = 'uniform', activation ='relu', input_dim = 8))
    regressor.add(Dense(units = 8, kernel_initializer = 'uniform', activation ='relu'))
    regressor.add(Dense(units = 1, kernel_initializer = 'uniform', activation ='sigmoid'))
    regressor.compile(optimizer = optimizer, loss = 'mse')
    return regressor

regressor = KerasRegressor(build_fn = build_regressor)
parameters = {'batch_size': [25, 32],
'epochs': [100, 1000],
'optimizer': ['adam', 'rmsprop']}
grid_search = GridSearchCV(estimator = regressor,
param_grid = parameters,
cv = 10)
grid_search = grid_search.fit(X_train, y_train)
best_parameters = grid_search.best_params_
best_accuracy = grid_search.best_score_

model = Sequential()
model.add(Dense(50,activation='relu'))
model.add(Dense(50,activation='relu'))
model.add(Dense(50,activation='relu'))
model.add(Dense(50,activation='relu'))
model.add(Dense(50,activation='relu'))
model.add(Dense(50,activation='relu'))
model.add(Dense(50,activation='relu'))
model.add(Dense(50,activation='relu'))
model.add(Dense(50,activation='relu'))

# Final output node for prediction
model.add(Dense(1))
model.compile(optimizer='adam',loss='mse')


# In[65]:


model.fit(X_train,y_train,epochs=1000)


# In[67]:


def FunctionFindBestParams(X_train, y_train, X_test, y_test):
    
    # Defining the list of hyper parameters to try
    batch_size_list=[5, 10, 15, 20]
    epoch_list  =   [5, 10, 50, 100]
    
    import pandas as pd
    SearchResultsData=pd.DataFrame(columns=['TrialNumber', 'Parameters', 'Accuracy'])
    
    # initializing the trials
    TrialNumber=0
    for batch_size_trial in batch_size_list:
        for epochs_trial in epoch_list:
            TrialNumber+=1
            # create ANN model
            model = Sequential()
            # Defining the first layer of the model
            model.add(Dense(units=5, input_dim=X_train.shape[1], kernel_initializer='normal', activation='relu'))
 
            # Defining the Second layer of the model
            model.add(Dense(units=5, kernel_initializer='normal', activation='relu'))
 
            # The output neuron is a single fully connected node 
            # Since we will be predicting a single number
            model.add(Dense(1, kernel_initializer='normal'))
 
            # Compiling the model
            model.compile(loss='mean_squared_error', optimizer='adam')
 
            # Fitting the ANN to the Training set
            model.fit(X_train, y_train ,batch_size = batch_size_trial, epochs = epochs_trial, verbose=0)
 
            MAPE = np.mean(100 * (np.abs(y_test-model.predict(X_test))/y_test))
            
            # printing the results of the current iteration
            print(TrialNumber, 'Parameters:','batch_size:', batch_size_trial,'-', 'epochs:',epochs_trial, 'Accuracy:', 100-MAPE)
            
            SearchResultsData=SearchResultsData.append(pd.DataFrame(data=[[TrialNumber, str(batch_size_trial)+'-'+str(epochs_trial), 100-MAPE]],
                                                                    columns=['TrialNumber', 'Parameters', 'Accuracy'] ))
    return(SearchResultsData)
 
 
######################################################
# Calling the function
ResultsData=FunctionFindBestParams(X_train, y_train, X_test, y_test)


# In[68]:


get_ipython().run_line_magic('matplotlib', 'inline')
ResultsData.plot(x='Parameters', y='Accuracy', figsize=(15,4), kind='line')


# In[69]:


#test_predictions


# In[70]:


from sklearn.metrics import mean_squared_error,mean_absolute_error,explained_variance_score


# In[71]:


predictions_test = model.predict(X_test)


# In[72]:


predictions_train = model.predict(X_train)


# In[73]:


#Create a Scatterplot of the real Linear Regression test values versus the Predicted Values.


# In[74]:


# Create a scatterplot of the real test values versus the predicted values.
ANNtrain=plt.scatter(y_train,predictions_train,color='red',marker='+',label='ANN_model ')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
R = r2_score(y_train, predictions_train)
plt.title('Training cross- plot of ANN model ')
plt.grid()
print(R)
m, b = np.polyfit(y_train, predictions_train, 1)
plt.plot(y_train, m*y_train+b,linestyle='--',c='blue',label='R=0.97')
plt.legend()
#plt.savefig('ANN-test')


# In[75]:


predictions_test=pd.DataFrame(predictions_test)
predictions_train=pd.DataFrame(predictions_train)
test=pd.DataFrame(y_test)
train=pd.DataFrame(y_train)


# In[76]:


# Create a scatterplot of the real test values versus the predicted values.
ANNtest=plt.scatter(y_test,predictions_test,color='red',marker='+',label='ANN_model ')
plt.xlabel(('Actual BTM,(F) '))
plt.ylabel(('Predicted BTM,(F) '))
R = r2_score(y_test, predictions_test)
plt.title('Testing cross- plot of ANN model ')
plt.grid()
print(R)
m, b = np.polyfit(y_test, predictions_test, 1)
plt.plot(y_test, m*y_test+b,linestyle='--',c='blue',label='R=0.81')
plt.legend()
#plt.savefig('ANN-test')


# In[77]:


from sklearn import metrics
print('MAE:', metrics.mean_absolute_error(y_test, predictions_test))
print('MSE:', metrics.mean_squared_error(y_test, predictions_test))
print('RMSE:', np.sqrt(metrics.mean_squared_error(y_test, predictions_test)))
y_test.mean()


# In[78]:


print('MAE:', metrics.mean_absolute_error(y_train, predictions_train))
print('MSE:', metrics.mean_squared_error(y_train, predictions_train))
print('RMSE:', np.sqrt(metrics.mean_squared_error(y_train, predictions_train)))
MAPE=np.mean((train - predictions_train) /train ) * 100
MAPE


# # MACHINE LEARNING MODELS COMPARISM

# In[86]:


models= [lin_reg, poly_reg, tree, forest, knn]

from sklearn import metrics
from sklearn.metrics import r2_score


plt.scatter(y_test,y_pred_LR,color='green',marker='+',label="Linear Reg. model predicted")
plt.scatter(y_test,y_pred_pol,color='blue',marker='*',label="Polynomial Reg. model predicted")
plt.scatter(y_test,y_pred_tree,color='orange',marker='*',label="Decision Tree model predicted")
plt.scatter(y_test,y_pred_forest,color='red',marker='o',label="Random Forest model predicted")
plt.scatter(y_test,y_pred_knn,color='brown',marker='^',label="knn model predicted")


R = r2_score(y_test,y_pred_LR )
R2 = r2_score(y_test,y_pred_pol )
R3 = r2_score(y_test,y_pred_tree )
R4 = r2_score(y_test, y_pred_forest)
R5 = r2_score(y_test,y_pred_knn )
 

plt.xlabel(('Actual BTM(F) '))
plt.ylabel(('Predicted BTM(F) '))

print(R)
print(R2)
print(R3)
print(R4)
print(R5)

m_test, b_test = np.polyfit(y_test, y_pred_LR, 1)
m_poly_test, b_poly_test  = np.polyfit(y_test, y_pred_pol, 1)
m_tree_test, b_tree_test = np.polyfit(y_test, y_pred_tree, 1)
m_forest_test, b_forest_test = np.polyfit(y_test, y_pred_forest, 1)
m_knn_test, b_knn_test = np.polyfit(y_test, y_pred_knn, 1)


#plt.plot(y_test, m*y_test+b,linestyle='--',c='red',label="R_DT=0.74")

plt.plot(y_test, m_test*y_test+b_test,linestyle='--',c='green',label="R_LR=0.80")
plt.plot(y_test, m_poly_test*y_test+b_poly_test,linestyle='--',c='blue',label="R_Poly=1.0")
plt.plot(y_test, m_tree_test*y_test+b_tree_test,linestyle='--',c='orange',label="R_Tree=1.0")
plt.plot(y_test, m_forest_test*y_test+b_forest_test,linestyle='--',c='red',label="R_Forest=0.91")
plt.plot(y_test, m_knn_test*y_test+b_knn_test,linestyle='--',c='brown',label="R_KNN=0.82")

plt.legend()
plt.title('Comparison of Test cross-plot of the Selected Machine Models')
plt.grid()

#plt.savefig('Machine-test')


# In[ ]:


models= [tree, forest, knn]
from sklearn import metrics
from sklearn.metrics import r2_score
tree_m=tree.fit(X_train, y_train)
forest_m=forest.fit(X_train, y_train)
knn_m=knn.fit(X_train, y_train)
y_pred_DT= tree_m.predict(X_train)
y_pred_F= forest_m.predict(X_train)
y_pred_knn= knn_m.predict(X_train)
#plt.scatter(y_test,y_pred_DT,color='red',marker='*',label="DT model predicted")
plt.scatter(y_train,y_pred_F,color='green',marker='o',label="RF model␣
("→predicted")")
plt.scatter(y_train,y_pred_knn,color='orange',marker='^',label="knn model␣
("→predicted")")
R = r2_score(y_train,y_pred_DT )
R2 = r2_score(y_train,y_pred_F )
R3 = r2_score(y_train,y_pred_knn )
plt.xlabel(('Actual Pwf(psia) '))
plt.ylabel(('Predicted Pwf(psia) '))
print(R)
print(R2)
print(R3)
m, b = np.polyfit(y_train, y_pred_DT, 1)
m2, b2 = np.polyfit(y_train, y_pred_F, 1)
m3, b3 = np.polyfit(y_train, y_pred_knn, 1)
#plt.plot(y_test, m*y_test+b,linestyle='--',c='red',label="R_DT=0.74")
plt.plot(y_train, m2*y_train+b2,linestyle='--',c='green',label="R_RF=0.96")
plt.plot(y_train, m3*y_train+b3,linestyle='--',c='orange',label="R_knn=1")
plt.legend()
plt.title('Training cross- plot of RF&KNN_models')
plt.grid()
#plt.savefig('machine_train')


# # OPTIMIZE TO PREDICT OIL PRODUCED

# In[89]:


df = pd.read_csv('Dataset.csv')

df=dfn.dropna()

df = df.drop(['S.N'], axis=1)

df.info()


# In[91]:


X = df.drop(['Qo(bbl/day)','Qg(Mscf/day)','Qw(bbl/day)'],axis=1)
Y = df[['Qo(bbl/day)','Qg(Mscf/day)','Qw(bbl/day)']]

print ('Features shape', X.shape)
print('Target shape', Y.shape)


# In[93]:


X_train, X_test, y_train, y_test = train_test_split(X,Y,test_size=0.3, random_state=42, shuffle =True)

Time=df.iloc[:,0]
Time_train, Time_test = train_test_split(Time, test_size=0.3, random_state=42)


# # Polynomial Regression Model

# In[101]:




from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge

poly = PolynomialFeatures(degree = 4)
X_pol_train = poly_reg.fit_transform(X_train)
lin_reg = LinearRegression()
lin_reg.fit(X_pol_train, y_train)
y_Pred_poly_t = lin_reg.predict(X_pol_train)


# In[144]:


predict_train = pd.DataFrame(y_Pred_poly_t, columns = ['Qo','Qg','Qw'])
predict_train


# In[228]:


y = y_train
X_train_np = np.array(X_train)
y_np = np.array(y)

#Poly_Reg_Train = plt.scatter(y_train,y_Pred_poly_t, color='red',marker='+',label='Poly_Reg_Train')
plt.xlabel(('Actual Hydrocarbon,(F) '))
plt.ylabel(('Predicted Hydrocarbon,(F) '))

R = r2_score(y_train, y_Pred_poly_t)
print(R)

def abline(slope, intercept):
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '-')
    
plt.plot(y_Pred_poly_t,y_np,'o')
plt.xlabel('Predicted Oil, Gas, Water(hydrocarbon units)')#,color='white')
plt.ylabel('Actual Oil, Gas, Water (hydrocarbon units)')#,color='white')
plt.title('Polynomial_Train (Predicted vs. Actual Hydrocarbon Produced) ')#,color='white')
plt.tick_params(axis='x', colors='black')
plt.tick_params(axis='y', colors='black')
abline(1,0)
plt.grid()
plt.show()


# In[191]:


from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Ridge

poly = PolynomialFeatures(degree = 4)
X_pol_test = poly_reg.fit_transform(X_test)
lin_reg = LinearRegression()
lin_reg.fit(X_pol_test, y_test)
y_Pred_poly = lin_reg.predict(X_pol_test)


# In[145]:


predict_test = pd.DataFrame(y_Pred_poly, columns = ['Qo','Qg','Qw'])
predict_test


# In[189]:


y = y_test
X_train_np = np.array(X_test)
y_np = np.array(y)

Poly_Reg_Test = plt.scatter(y_test,y_Pred_poly, color='red',marker='+',label='Poly_Reg_Test')
plt.xlabel(('Actual Hydrocarbon,(F) '))
plt.ylabel(('Predicted Hydrocarbon,(F) '))

R = r2_score(y_test, y_Pred_poly)

plt.plot(y_np, y_Pred_poly,'o')
plt.grid()
print(R)

def abline(slope, intercept):
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '-')
    
plt.plot(y_Pred_poly_t,y_np,'o')
plt.xlabel('Predicted Oil, Gas, Water(hydrocarbon units)')#,color='white')
plt.ylabel('Actual Oil, Gas, Water (hydrocarbon units)')#,color='white')
plt.title('Polynomial_Test (Predicted vs. Actual Hydrocarbon Produced) ')#,color='white')
plt.tick_params(axis='x', colors='black')
plt.tick_params(axis='y', colors='black')
abline(1,0)
plt.grid()
plt.show()


# In[ ]:





# In[220]:


y = y_test
X_test_np = np.array(X_test)
y_np = np.array(y)

Poly_Reg_Test = plt.scatter(y_test,y_Pred_poly, color='red',marker='+',label='Poly_Reg_Train')
plt.xlabel(('Actual Oil, Gas, Water () '))
plt.ylabel(('Predicted  Oil, Gas, Water () '))

R = r2_score(y_test, y_Pred_poly)
print(R)

def abline(slope, intercept):
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '-')
    
#predict y values for training data

#plot predicted vs actual
plt.plot(y_Pred_poly,y_np,'o')
plt.xlabel('Predicted Oil, Gas, Water(hydrocarbon units)')#,color='white')
plt.ylabel('Actual Oil, Gas, Water (hydrocarbon units)')#,color='white')
plt.title('Polynomial_Test (Predicted vs. Actual Hydrocarbon Produced) ')#,color='white')
plt.tick_params(axis='x', colors='black')
plt.tick_params(axis='y', colors='black')
abline(1,0)
plt.grid()
plt.show()


# # Decision Tree

# In[225]:


# fit the model
tree.fit(X_train, y_train) 

# then predict on the train set
y_Predict_tree_y = tree.predict(X_train)
    
y = y_train
X_train_np = np.array(X_train)
y_np = np.array(y)

#tree_Train = plt.scatter(y_train,y_Predict_tree_y, color='red',marker='+',label='Poly_Reg_Train')
plt.xlabel(('Actual Hydrocarbon,(F) '))
plt.ylabel(('Predicted Hydrocarbon,(F) '))


R = r2_score(y_train, y_Predict_tree_y)
print(R)

def abline(slope, intercept):
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '-')
    
#predict y values for training data

#plot predicted vs actual
plt.plot(y_Predict_tree_y, y_np,'o')
plt.xlabel('Predicted Oil, Gas, Water(hydrocarbon units)')#,color='white')
plt.ylabel('Actual Oil, Gas, Water (hydrocarbon units)')#,color='white')
plt.title('Decision Tree_Train (Predicted vs. Actual Hydrocarbon Produced) ')#,color='white')
plt.tick_params(axis='x', colors='black')
plt.tick_params(axis='y', colors='black')
abline(1,0)
plt.grid()
plt.show()


# In[227]:


# fit the model
tree.fit(X_test, y_test) 

# then predict on the train set
y_Predict_tree = tree.predict(X_test)
 
y = y_test
X_train_np = np.array(X_test)
y_np = np.array(y)

#tree_Test = plt.scatter(y_test, y_Predict_tree, color='red',marker='+',label='Poly_Reg_Train')
plt.xlabel(('Actual Hydrocarbon,(F) '))
plt.ylabel(('Predicted Hydrocarbon,(F) '))

R = r2_score(y_test, y_Predict_tree)
print(R)

def abline(slope, intercept):
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '-')

#predict y values for training data
y_hat = y_Predict_tree

#plot predicted vs actual
plt.plot(y_hat,y_np,'o')
plt.xlabel('Predicted Oil, Gas, Water(hydrocarbon units)')#,color='white')
plt.ylabel('Actual Oil, Gas, Water (hydrocarbon units)')#,color='white')
plt.title('Decision Tree_Test (Predicted vs. Actual Hydrocarbon Produced) ')#,color='white')
plt.tick_params(axis='x', colors='black')
plt.tick_params(axis='y', colors='black')
abline(1,0)
plt.grid()
plt.show()


# In[238]:


Decision_predict_test = pd.DataFrame(y_Predict_tree, columns = ['Qo','Qg','Qw'])
Decision_predict_test


# # Random Forest

# In[202]:


forest_model = RandomForestRegressor(random_state=48)

forest_model.fit(X_train, y_train) # fit the model

y_predict_forest_t = forest_model.predict(X_train)


# In[204]:


Forest_predict_train = pd.DataFrame(y_predict_forest_t, columns = ['Qo','Qg','Qw'])
Forest_predict_train


# In[229]:


y = y_train
X_train_np = np.array(X_train)
y_np = np.array(y)

R = r2_score(y_train, y_predict_forest_t)
print(R)

def abline(slope, intercept):
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '-',label='R=0.93')
    

#plot predicted vs actual
plt.plot(y_predict_forest_t,y_np,'o', label="Random Forest")
plt.xlabel('Predicted Oil, Gas, Water(hydrocarbon units)')#,color='white')
plt.ylabel('Actual Oil, Gas, Water (hydrocarbon units)')#,color='white')
plt.title('Random Forest_Train (Predicted vs Actual Hydrocarbon) ')#,color='white')
plt.tick_params(axis='x', colors='black')
plt.tick_params(axis='y', colors='black')
abline(1,0)
plt.grid()
plt.show()


# In[219]:


y_predict_forest = forest_model.predict(X_test)

y = y_test
X_train_np = np.array(X_test)
y_np = np.array(y)

R = r2_score(y_test, y_predict_forest)
print(R)

def abline(slope, intercept):
    axes = plt.gca()
    x_vals = np.array(axes.get_xlim())
    y_vals = intercept + slope * x_vals
    plt.plot(x_vals, y_vals, '-')
    

#plot predicted vs actual
plt.plot(y_predict_forest,y_np,'o')
plt.xlabel('Predicted Oil, Gas, Water(hydrocarbon units)')#,color='white')
plt.ylabel('Actual Oil, Gas, Water (hydrocarbon units)')#,color='white')
plt.title('Random Forest_Test (Predicted vs Actual Hydrocarbon) ')#,color='white')
plt.tick_params(axis='x', colors='black')
plt.tick_params(axis='y', colors='black')
abline(1,0)
plt.grid()
plt.show()


# In[234]:


Forest_predict_test = pd.DataFrame(y_predict_forest, columns = ['Qo','Qg','Qw'])
Forest_predict_test.head(60)


# In[233]:


y_test.head(60)


# In[ ]:




